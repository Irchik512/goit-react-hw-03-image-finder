export default function Notification({message}) {
  return (
    <p>{message}</p>
  );
}
